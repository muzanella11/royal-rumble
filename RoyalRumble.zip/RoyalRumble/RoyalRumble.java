import java.util.List;

public class RoyalRumble {
  public List<String> getSortedList(List<String> names) {
    return null;
  }
}
